# ap3_controller
AP3 (AmPurify-3) Contoller for Volumio
- Mode Select
- Volume Up/Down

< To Do >
* Fix a failure with "volumio plugin install" command.
* Remove useless folder menu (right-upper placed)
* Improve the icons & albums for UI.
* Find anything for configurable stuffs.
