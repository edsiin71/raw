# ap3_controller
AP3 (AmPurify-3) Contoller for Volumio
- Mode Select
- Volume Up/Down
